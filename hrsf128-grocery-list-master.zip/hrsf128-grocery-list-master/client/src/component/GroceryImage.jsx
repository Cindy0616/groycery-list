import React from 'react';

const GroceryImage = props => (
  <div>
    <img src="grocery-bags.png"/>
    <h1>Grocery List</h1>
  </div>
);

export default GroceryImage;


